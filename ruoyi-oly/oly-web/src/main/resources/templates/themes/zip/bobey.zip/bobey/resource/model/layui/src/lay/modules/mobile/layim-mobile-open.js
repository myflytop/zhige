/**

 @Name：layim mobile 开源包
 @Author：贤心
 @License：MIT
    
 */
 
layui.define(function(exports){
  exports('layim-mobile', layui.v);
});