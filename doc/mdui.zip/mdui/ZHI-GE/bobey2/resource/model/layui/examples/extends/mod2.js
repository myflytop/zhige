
layui.define(['jquery', 'form'], function(exports){
  console.log(layui.$)
  
  exports('mod2', {
    name: 'mod2'
  })
});