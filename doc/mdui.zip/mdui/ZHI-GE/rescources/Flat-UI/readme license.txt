This item has been downloaded from the Designmodo - https://designmodo.com/

LICENSE:

Use for Free, but Please Set a Link

We distribute them under the license called Creative Commons Attribution-NoDerivs 3.0 Unported. 
The UI Kits, mockups, icons, templates, themes and photos are free for personal use and also free for commercial use, but we require linking to our website - https://designmodo.com/ .